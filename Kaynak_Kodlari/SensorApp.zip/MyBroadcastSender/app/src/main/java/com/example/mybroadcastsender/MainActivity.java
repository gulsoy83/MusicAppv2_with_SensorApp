package com.example.mybroadcastsender;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    TextView Isik, AC;
    private SensorManager mSM;
    Sensor Is, As;
    float ivalues,avalues;
    int flag=1;

    @Override
    protected void onPostResume() {
        super.onPostResume();
        mSM.registerListener(this,Is,SensorManager.SENSOR_DELAY_NORMAL);
        mSM.registerListener(this,As,SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        mSM.unregisterListener(this);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Isik = (TextView) findViewById(R.id.sensorIStatusTV);
        AC = (TextView) findViewById(R.id.sensorACStatusTV);

        mSM = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        Is = mSM.getDefaultSensor(Sensor.TYPE_LIGHT);
        As = mSM.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        //float ivalues,avalues;
        if(sensorEvent.sensor.getType() == Sensor.TYPE_LIGHT){
            ivalues = sensorEvent.values[0];
            Isik.setText(" "+ivalues);
        }
        if(sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER){
            avalues = sensorEvent.values[0];
            AC.setText(" "+avalues);
        }

    if(flag%75==0)
        if( avalues>0.5 && ivalues>50){
            Intent intent = new Intent();
            intent.setAction("com.example.mybroadcastsender.SES");
            intent.putExtra("data1",   "AYDINLIK HAREKETLI");
            sendBroadcast(intent);
            flag=1;

        }else if(avalues>0.5 && ivalues<50){
            Intent intent = new Intent();
            intent.setAction("com.example.mybroadcastsender.SES");
            intent.putExtra("data1",   "KARANLIK HAREKETLI");
            sendBroadcast(intent);
            flag=1;

        }
        else if(avalues<0.5 && ivalues>50){
            Intent intent = new Intent();
            intent.setAction("com.example.mybroadcastsender.SES");
            intent.putExtra("data1",   "AYDINLIK SABIT");
            sendBroadcast(intent);
            flag=1;

        }else if(avalues<0.5 && ivalues<50){
            Intent intent = new Intent();
            intent.setAction("com.example.mybroadcastsender.SES");
            intent.putExtra("data1",   "KARANLIK SABIT");
            sendBroadcast(intent);
            flag=1;
        }
        else{
            flag++;
        }
        else
            flag++;




    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}