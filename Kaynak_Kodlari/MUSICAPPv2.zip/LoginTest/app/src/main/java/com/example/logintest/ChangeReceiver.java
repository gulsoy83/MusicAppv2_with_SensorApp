package com.example.logintest;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Handler;
import android.widget.Toast;

public class ChangeReceiver extends BroadcastReceiver {
    @Override

    public void onReceive(Context context, Intent intent) {
        String value = intent.getStringExtra("data1");


        if(value.compareTo("AYDINLIK SABIT")==0){

            AudioManager audioManager = (AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0);
            Toast.makeText(context, value,Toast.LENGTH_SHORT).show();

        }
        else if(value.compareTo("AYDINLIK HAREKETLI")==0 || value.compareTo("KARANLIK HAREKETLI")==0 || value.compareTo("KARANLIK SABIT")==0){


            AudioManager audioManager = (AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 5, 0);
            Toast.makeText(context, value,Toast.LENGTH_SHORT).show();

        }
        else{
            Toast.makeText(context, value,Toast.LENGTH_SHORT).show();
        }



    }

}
