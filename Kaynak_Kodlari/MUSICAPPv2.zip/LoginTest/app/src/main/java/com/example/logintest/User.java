package com.example.logintest;

public class User {
    String ad, soyad, mail, username, password;
    public User(String ad, String soyad, String mail, String username, String password){
        this.ad = ad;
        this.soyad = soyad;
        this.mail = mail;
        this.username = username;
        this.password = password;
    }

}
